import Foundation
import SwiftData

enum StorageManager {
    
    static func save<T: Codable>(_ value: T, forKey key: String) {
        do {
            let data = try JSONEncoder().encode(value)
            
            let context = ModelContext(SwiftDataStack.sharedContainer)
            
            // 先找既有的 key
            let descriptor = FetchDescriptor<KeyValueRecord>(
                predicate: #Predicate { $0.key == key }
            )
            let existing = try context.fetch(descriptor).first
            
            if let existing {
                existing.data = data
            } else {
                context.insert(KeyValueRecord(key: key, data: data))
            }
            
            try context.save()
        } catch {
            print("Storage save failed:", error)
        }
    }
    
    static func load<T: Codable>(_ type: T.Type, forKey key: String) -> T? {
        do {
            let context = ModelContext(SwiftDataStack.sharedContainer)
            let descriptor = FetchDescriptor<KeyValueRecord>(
                predicate: #Predicate { $0.key == key }
            )
            guard let record = try context.fetch(descriptor).first else {
                return nil
            }
            return try JSONDecoder().decode(type, from: record.data)
        } catch {
            print("Storage load failed:", error)
            return nil
        }
    }
    
    /// （可選）如果你原本有「重置/清除」需求，可以用這個
    static func remove(forKey key: String) {
        do {
            let context = ModelContext(SwiftDataStack.sharedContainer)
            let descriptor = FetchDescriptor<KeyValueRecord>(
                predicate: #Predicate { $0.key == key }
            )
            if let record = try context.fetch(descriptor).first {
                context.delete(record)
                try context.save()
            }
        } catch {
            print("Storage remove failed:", error)
        }
    }
}
