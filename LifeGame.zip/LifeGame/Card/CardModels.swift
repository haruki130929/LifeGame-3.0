import SwiftUI
import Foundation

// MARK: - CardSize
enum CardSize: String, Codable, CaseIterable {
    case small, medium, large
    
    /// ✅ 新版：依「目前 grid 最大欄數」決定要跨幾欄
    func span(maxColumns: Int) -> Int {
        switch self {
        case .small:
            return 1
        case .medium:
            return min(2, maxColumns)
        case .large:
            return maxColumns
        }
    }
    
    /// ✅ 相容層：舊程式還在用 `.columns` 不會爆
    /// （暫時假設舊版最大 3 欄）
    var columns: Int {
        span(maxColumns: 3)
    }
    
    var height: CGFloat {
        switch self {
        case .small: return 110
        case .medium: return 160
        case .large: return 270
        }
    }
}

// MARK: - CardType

enum CardType: String, CaseIterable, Identifiable, Codable {
    case quickStart
    case todayStatus
    case calendar
    case dailyLog
    case editCards
    case todoQuadrant
    case tomorrowRing
    case bagRequired
    case monthlyScoreCalendar
    
    var id: String { rawValue }
    
    var title: String {
        switch self {
        case .quickStart: return "快速開始"
        case .todayStatus: return "今日狀態"
        case .calendar: return "行事曆"
        case .dailyLog: return "每日紀錄"
        case .editCards: return "編輯卡片"
        case .todoQuadrant: return "待辦四象限"
        case .tomorrowRing: return "時間圓環"
        case .bagRequired: return "收拾書包"
        case .monthlyScoreCalendar: return "本月結算"
        }
    }
    
    var icon: String {
        switch self {
        case .quickStart: return "bolt"
        case .todayStatus: return "heart.text.square"
        case .calendar: return "calendar"
        case .dailyLog: return "square.and.pencil"
        case .editCards: return "square.grid.2x2"
        case .todoQuadrant: return "list.bullet.clipboard"
        case .tomorrowRing: return "clock"
        case .bagRequired: return "backpack"
        case .monthlyScoreCalendar: return "calendar.badge.clock"
        }
    }
    
    var defaultSize: CardSize {
        switch self {
        case .todayStatus: return .medium
        case .calendar: return .large
        case .dailyLog: return .large
        case .quickStart: return .small
        case .editCards: return .small
        case .todoQuadrant: return .large
        case .tomorrowRing: return .large
        case .bagRequired: return .medium
        case .monthlyScoreCalendar: return .large
        }
    }
}

// MARK: - CardItem

struct CardItem: Identifiable, Codable, Equatable {
    var type: CardType
    var size: CardSize
    
    var id: String { type.rawValue }
}
