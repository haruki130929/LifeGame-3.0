import SwiftUI
import SwiftData

@main
struct LifeGameApp: App {
    @StateObject private var theme = ThemeStore()
    @StateObject private var calendarStore = CalendarStore()
    @StateObject private var calendarSettings = CalendarSettingsStore()
    @StateObject private var fab = FabStore()
    @StateObject private var wishStore = WishStore()
    @StateObject private var ledgerStore = LedgerStore()
    @StateObject private var moodHistory = MoodHistoryStore()
    
    var body: some Scene {
        WindowGroup {
            HomeRootContainerView()
                .environmentObject(theme)
                .environmentObject(calendarStore)
                .environmentObject(calendarSettings)
                .environmentObject(fab)
                .environmentObject(wishStore)
                .environmentObject(ledgerStore)
                .environmentObject(moodHistory)
        }
        .modelContainer(SwiftDataStack.sharedContainer)
    }
}
